{
    TH1D h0("h1","h1",100,-5,5);
//     h0.FillRandom("gaus",1000);
    h0.Draw();
}

	

