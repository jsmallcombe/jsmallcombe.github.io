void func1b(){
    TFile inputFile("ExampleFile.root","READ");
    gROOT->cd();
    
    TH1* h = (TH1*) inputFile.Get("Y");
    
    TH1* hc = (TH1*) h->Clone("Yclone");
    
    TFile outFile("OutTest.root","RECREATE");
    hc->Write("NewNamecycle");//Particularly useful if not TNamed
}

	

