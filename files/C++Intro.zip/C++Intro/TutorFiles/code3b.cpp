//g++ code3.cpp -o Program3
//pointers intro

#include <iostream>
#include <sstream>
#include <math.h>
#include <iomanip>


using namespace std;

int main(int argc, char *argv[]){

    int first=4;
    
    cout<<setw(10)<<"first = "<<first<<endl;
    cout<<endl;
    
    cout<<setw(10)<<"&first = "<<&first<<endl;
    
    int *point1=&first;
    cout<<endl;
    cout<<setw(10)<<"point1 = "<<point1<<endl;
    cout<<setw(10)<<"*point = "<<*point1<<endl;
    cout<<setw(10)<<"&point = "<<&point1<<endl;
    
    cout<<endl;
    *point1+=1;   
    cout<<setw(10)<<"first = "<<first<<endl;
    
	return 0;
}

	

    
