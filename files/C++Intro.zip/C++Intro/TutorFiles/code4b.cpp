//g++ code4.cpp -o Program4
//scope and heap

#include <iostream>
#include <sstream>
#include <math.h>
#include <iomanip>


using namespace std;

double* arbfunc(){
    double* funcpoint=new double(2);
    return funcpoint;
}

int main(int argc, char *argv[]){

    double* mainpoint=arbfunc();
    
    cout<<"mainpoint address  = "<<mainpoint<<endl;
    cout<<"mainpoint derefval  = "<<*mainpoint<<endl;    
    
    delete mainpoint;
        
	return 0;
}

	

    
