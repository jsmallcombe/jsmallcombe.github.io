//g++ code2.cpp -o Program2
//basic function

#include <iostream>
#include <sstream>
#include <math.h>

using namespace std;

double Deg2Rad(double deg){
    double rad=deg*M_PI/180.;
    return rad;
}

int main(int argc, char *argv[]){

    for(int i=1;i<argc;i++){
        stringstream ss;
        ss<<argv[i];
        double DEG;
        ss>>DEG;
        cout<<" Argument "<<i<<" in radians "<<Deg2Rad(DEG)<<endl;
    }
    
	return 0;
}

	

    
