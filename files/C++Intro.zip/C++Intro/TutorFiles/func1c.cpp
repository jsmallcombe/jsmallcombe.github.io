void func1c(){
    TFile inputFile("ExampleFile.root","READ");
    gROOT->cd();

    TFile outFile("OutTest.root","RECREATE");
    TH1* hc = (TH1*) inputFile.Get("Y")->Clone("Yclone");
    
    outFile.Write();
}

	

