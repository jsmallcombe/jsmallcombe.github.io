void func1(){
    
    //Method 1
    TH1* h = nullptr;
    inputFile.GetObject("myHisto",h);

    //Method 2 (should inhert from TObject)
    TH1* h = (TH1*) inputFile.Get("myHisto");

    h->Draw();
}

	

