//g++ code1.cpp -o Program1
//int main arguments

#include <iostream>

using namespace std;

int main(int argc, char *argv[]){

    cout<<"Input Argument "<<0<<" is "<<argv[0]<<endl;
    
	return 0;
}

	

