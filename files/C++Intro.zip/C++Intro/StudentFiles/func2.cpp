void func2(){
    // Prepare some input
    ////
      
    //Prepare some output 
    TFile outFile("OutTestNew.root","RECREATE");
        TH1D* h1 = new TH1D("h1","NewHist1",10,0,10);//Already in output
        TH1D* h2 = new TH1D("h2","NewHist2",10,0,10);//Already in output
        TH1D* h3 = new TH1D("h3","NewHist3",10,0,10);//Already in output
    gROOT->cd();
    
    // Do many things
    // Process some date etc
    h1->FillRandom("gaus",1000);
    
    //Finished so Write
    outFile.Write();//Writes all 3 histograms
    outFile.Close();
}

	

