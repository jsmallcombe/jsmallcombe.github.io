//g++ code3.cpp -o Program3
//pointers intro

#include <iostream>
#include <sstream>
#include <math.h>
#include <iomanip>


using namespace std;

int main(int argc, char *argv[]){

    int first=4;
    
    cout<<"first = "<<first<<endl;
    
    cout<<"&first = "<<&first<<endl;
    cout<<endl;
    
	return 0;
}

	

    
