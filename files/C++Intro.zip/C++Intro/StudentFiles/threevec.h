class ThreeVec{
    public:
        //Constructor
        ThreeVec(double X=0,double Y=0,double Z=0):x(X),y(Y),z(Z){};
        //Destructor
        ~ThreeVec(){};
        
        //Operators
        ThreeVec operator +(ThreeVec Add){
            ThreeVec ret;
            ret.x=x+Add.x;
            ret.y=y+Add.y;
            ret.z=z+Add.z;
            return ret;
        };
        
        void operator +=(ThreeVec Add){
            ThreeVec ret;
            x+=Add.x;
            y+=Add.y;
            z+=Add.z;   
        };
        
        //Methods
        double mag(){
            return sqrt(pow(x,2)+pow(y,2)+pow(z,2));
        }
        
        double theta(){
            return atan(sqrt(pow(x,2)+pow(y,2))/z);
        }
        
        //Attributes
        double x,y,z;
        
    private:
};
