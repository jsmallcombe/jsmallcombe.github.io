//g++ code7.cpp -o Program7
//class 2

#include <iostream>
#include <sstream>
#include <math.h>
#include <iomanip>
#include <vector>

using namespace std;

#include "threevec.h"

class Detector : public ThreeVec{
public:
    Detector(double X=0,double Y=0,double Z=0):ThreeVec(X,Y,Z){};
    ~Detector(){};
    vector<double> energyhits;
};

class HPGe : public Detector{
public:
    HPGe(){};
    ~HPGe(){};
    int GetID(){return ID;}
private:
    int ID;
};

int main(int argc, char *argv[]){
    
    ThreeVec V(3,4,2);
    Detector D(1,2,3);
    HPGe* G=new HPGe();
    
    
	return 0;
}

	

    
