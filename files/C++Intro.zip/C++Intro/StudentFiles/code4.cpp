//g++ code4.cpp -o Program4
//scope and heap

#include <iostream>
#include <sstream>
#include <math.h>
#include <iomanip>


using namespace std;

double* arbfunc(){
    double arb=2;
    double* funcpoint=&arb;
    return funcpoint;
}

int main(int argc, char *argv[]){

    double* mainpoint=arbfunc();
    
    cout<<"mainpoint address  = "<<mainpoint<<endl;
    cout<<"mainpoint derefval  = "<<*mainpoint<<endl;    
    
	return 0;
}

	

    
