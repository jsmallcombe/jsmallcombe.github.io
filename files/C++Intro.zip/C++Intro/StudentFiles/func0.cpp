void func0(){
    ThreeVec One(1,2,3);
    ThreeVec Two(1,2,3);
    
    One+=Two;
    
    cout<<One.mag()<<endl;
    
}

	

