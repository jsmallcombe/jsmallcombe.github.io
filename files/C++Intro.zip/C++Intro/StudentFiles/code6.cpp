//g++ code6.cpp -o Program6
//class 1

#include <iostream>
#include <sstream>
#include <math.h>
#include <iomanip>


using namespace std;

class ThreeVec{
    public:
    //Methods
        
        //Constructor
        ThreeVec(){
        };
        //Destructor
        ~ThreeVec(){};
        
    //Attributes
        double x,y,z;
        
    private:
};

int main(int argc, char *argv[]){
    
    ThreeVec A;
    A.x=4;
    
	return 0;
}

	

    
