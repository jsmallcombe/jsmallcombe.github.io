//g++ code5.cpp -o Program5
//scope and heap 2

#include <iostream>
#include <sstream>
#include <math.h>
#include <iomanip>


using namespace std;

int main(int argc, char *argv[]){
    
    for(int i=0;i<10;i++){
        double var;
        cout<<"Local var address "<<&var<<endl;
    }
    
    double vararray[10];
    for(int i=0;i<10;i++){
        cout<<"Local vararray "<<i<<" address "<<&vararray[i]<<endl;
    }


    for(int i=0;i<10;i++){
        double* var=new double;
        cout<<"Heap var address  "<<var<<endl;
//         delete var;
    }
    
	return 0;
}

	

    
