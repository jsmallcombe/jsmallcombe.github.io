//g++ code0.cpp -o Program0
//hello world

#include <iostream>

using namespace std;

int main(int argc, char *argv[]){
    
	return 0;
    
}

	

