{
    
	// Create a new graph with error bars
	// Load data from a plain text file to fill the graph
	TGraphErrors SourceData("GraphData.txt");
	
	// Graphical axis for a TGraph/TGraphErrors are handled by the TH1 class
	// GetHistogram returns a pointer to this drawing histogram
	// By default the Y-axis only covers the range of the data, SetMinimum(0) shows Y=0
	SourceData.GetHistogram()->SetMinimum(0);
		
	// When drawing a graph we must include the option "a" to draw the axis
	// Option "p" draw data as points option "l" as a line
    SourceData.Draw("ap");
    
	// Create a TF1 to fit
    TF1 LineFit("LineFit","x*[1]+[0]",50,2050);

	// Fit command the same as for TH1
	SourceData.Fit(&LineFit,"R");

}
