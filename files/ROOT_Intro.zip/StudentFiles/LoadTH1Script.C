{
	//  A pointer for a histogram-type object, initially empty
	TH1* h1=nullptr;
		
	//  Create a TFile object to access .root files
	TFile InFile("TH1.root","READ");
	
	//  Check the .root file was found and opened.
	if(InFile.IsOpen()){
		
		//  Load the object saved with name "hist" into memory and assign the addess to pointer
		h1=(TH1*)InFile.Get("hist");
		
	}
	
	//  If loading the file or histogram failed the pointer h1 is still empty
	if(h1==nullptr){ 
		
		// Create an empty histogram to avoid segfault crash in this case
		h1= new TH1D();
		
	}

	//  Save the number of bins to a local variable
	int NX=h1->GetNbinsX();
	
	//  Save the bins width to a local variable
	double BW=h1->GetBinWidth(1);
	
	//  Print information to terminal 
	cout<<endl<<"Number of bins = "<<NX;
	cout<<endl<<"Bins width = "<<BW<<" MeV"<<endl;
	
	// Draw the histogram to the screen (creates a TCanvas is needed)
	h1->Draw();
}
