{
	
	//  A pointer for the TTree object, initially empty
	TTree* tree1=nullptr;
	TGraph* graph1=nullptr;
		
	//  Create a TFile object to access .root files
	TFile InFile("TTreeThree.root","READ");
	
	//  Check the .root file was found and opened.
	if(InFile.IsOpen()){
		//  Load the nambed objects into memory and assign the addess to pointer
		tree1=(TTree*)InFile.Get("DataTree");
		graph1=(TGraph*)InFile.Get("ThetaBeta");
	}
	
	//  If loading the file or objects failed the pointers are still empty
	if(tree1==nullptr){ 
		// Create an empty ttree to avoid segfault crash in this case
		tree1= new TTree();
	}
	if(graph1==nullptr){ 
		graph1= new TGraph();
	}
	
	// Declare variables for each simple varialbe branches into which data will be loaded
	// and pointers for complex class branches into which addresses will be set
	double GammaEnergy,ParticleEnergy;	
	TVector3 *ParticleVec,*GammaVec;
	
	tree1->SetBranchAddress("GammaVec", &GammaVec);
	tree1->SetBranchAddress("GammaEnergy", &GammaEnergy);
	tree1->SetBranchAddress("ParticleVec", &ParticleVec);
	tree1->SetBranchAddress("ParticleEnergy", &ParticleEnergy);
	
	//  Create a new histogram as local variable
	TH1D h1("H1","Energy",2000,0,2000);

	
	// Get the total number of events in the TTree
	Int_t nentries = tree1->GetEntries();
	
	// Loop over every event number of the TTree
	for(int jentry = 0; jentry<nentries; jentry++){
		
		// Load the data of the specified entry into the specified variable for each branch
		tree1->GetEntry(jentry);
		
		// Fill histogram with data from the specified event
		h1.Fill(GammaEnergy);
	}
	
	// Manually create a new TCanvas drawing environment each rather than having root automatically create one
	TCanvas C1;
	
	// Draw h1 on Canvas C1
	h1.Draw();
	
}

