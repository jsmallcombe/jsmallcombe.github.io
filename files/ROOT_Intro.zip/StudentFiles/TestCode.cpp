double TimesTwo(double input){
	return input*2;
}

void TestCode(){
	cout<<"This is function TestCode"<<endl;
}
