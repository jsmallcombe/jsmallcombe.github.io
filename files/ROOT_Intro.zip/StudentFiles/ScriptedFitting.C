{
	//  A pointer for the TTree object, initially empty
	TTree* tree1=nullptr;
		
	//  Create a TFile object to access .root files
	TFile InFile("TTreeOne.root","READ");
	
	//  Check the .root file was found and opened.
	if(InFile.IsOpen()){
		
		//  Load the object saved with name "DataTree" into memory and assign the addess to pointer
		tree1=(TTree*)InFile.Get("DataTree");
		
	}
	
	//  If loading the file or TTree failed the pointer tree1 is still empty
	if(tree1==nullptr){ 
		
		// Create an empty ttree to avoid segfault crash in this case
		tree1= new TTree();
		
	}

	//  Create a new histogram as local variable
	TH1D h1("H1","Charge",2000,0,2E6);

	// Declare a TF1 (one dimentional function) object to hold the formula and parameters we will fit
	TF1 f1("f1","[0]+x*[1]",4E5,8E5);
	
	// Manually create a new TCanvas drawing environment each rather than having root automatically create one when draw is called 
	TCanvas C1("C1","C1",1200,500);
	
	// Divide the TCanvas drawing environment to draw histograms side-by-side
	C1.Divide(3);
	
	// loop over different ID values
	for(int id=0;id<3;id++){
		
		// Select one of the divisions of C1 to be the current drawing destination
		C1.cd(id+1);
		
		// Create a stringstream variable, a useful c++ class for converting data to string types
		stringstream ss;
		
		// Input a mixture of text and number values into the stringstream (same syntax as cout)
		ss<<"ShieldCharge<=0&&ID=="<<id;
		
		// Draw the selected data from the tree into histogram H1
		// Our stringsteam is converted to the correct format for the selection input 
		tree1->Draw("HPGeCharge>>H1",ss.str().c_str());
		
		// Interogate h1 and extract information to estimate function parameters
		int binA=h1.FindBin(1E6);
		double yA=h1.GetBinContent(binA);
		
		// Set intial parameters guesses for the TF1 (where the minimisations should start from)
		f1.SetParameter(0,yA);
		f1.SetParameter(1,0);
		
		// Fit the histogram with the formula specified in the TF1 f1, using initial parameters (and ranges) set in f1
		// Option "R" is given as the second argument to the fit command so that range of f1 (not h1) is used.
		h1.Fit(&f1,"R");
		// & makes a pointer when we have a local variable, as the Fit function takes a pointer input
		
		// Retrieve a parameter from f1
		// This will have changed to the value reached during the chisquared minimisation of the TH1::Fit commands
		double p0=f1.GetParameter(0);
		
		// Output the retreived value		
		cout<<endl<<"For the fit to ID "<<id<<", parameter 0 has value "<<p0<<endl;
		
		// Calling TAxis::SetRange() with no arguments resets the histogram viewing range to full.
		h1.GetXaxis()->SetRange();
		
		// Special TH1 drawing command draws a copy of the histogram as it is right now so the view is not overwritten by the next loop
		h1.DrawCopy();
		
	} // End of the loop over ID values
	
}
