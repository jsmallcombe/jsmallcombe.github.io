{
    TH1D h1("h1","h1",100,-5,5);
    h1.FillRandom("gaus",1000);
    h1.Draw();
    h1.SetLineColor(1);
    h1.SetLineWidth(2);
}
