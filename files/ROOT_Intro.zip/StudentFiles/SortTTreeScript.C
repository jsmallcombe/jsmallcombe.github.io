{
	
	//  A pointer for the TTree object, initially empty
	TTree* tree1=nullptr;
		
	//  Create a TFile object to access .root files
	TFile InFile("TTreeTwo.root","READ");
	
	//  Check the .root file was found and opened.
	if(InFile.IsOpen()){
		//  Load the object saved with name "DataTree" into memory and assign the addess to pointer
		tree1=(TTree*)InFile.Get("DataTree");
	}
	
	//  If loading the file or histogram failed the pointer h1 is still empty
	if(tree1==nullptr){ 
		// Create an empty ttree to avoid segfault crash in this case
		tree1= new TTree();
	}

	// Declare variables for each branches into which data will be loaded for each event
	// (For complex classes only a pointer is needed)
	double HPGeEnergy, ScintEnergy;
	int TimeStampHPGe,TimeStampScint;
	
	// Set the address for each of the branches of the TTree 
	tree1->SetBranchAddress("HPGeEnergy", &HPGeEnergy);
	tree1->SetBranchAddress("ScintEnergy", &ScintEnergy);
	tree1->SetBranchAddress("TimeStampHPGe", &TimeStampHPGe);
	tree1->SetBranchAddress("TimeStampScint", &TimeStampScint);

	// Create histogram to be filled (local variable) 
	TH1D h1("H1","GammaEnergy",2000,0,2000);

	// Get the total number of events in the TTree
	Int_t nentries = tree1->GetEntries();
	
	// Loop over every event number of the TTree
	for(int jentry = 0; jentry<nentries; jentry++){
		
		// Load the data of the specified entry into the specified variable for each branch
		tree1->GetEntry(jentry);
		
		// Fill histogram with data from the specified event
		h1.Fill(HPGeEnergy);
	}
	
	// Manually create a new TCanvas drawing environment each rather than having root automatically create one
	TCanvas C1;
	
	// Draw h1 on Canvas C1
	h1.Draw();
}

