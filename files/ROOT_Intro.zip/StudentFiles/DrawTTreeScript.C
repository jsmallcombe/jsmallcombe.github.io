{
	//  A pointer for the TTree object, initially empty
	TTree* tree1=nullptr;
		
	//  Create a TFile object to access .root files
	TFile InFile("TTreeOne.root","READ");
	
	//  Check the .root file was found and opened.
	if(InFile.IsOpen()){
		
		//  Load the object saved with name "DataTree" into memory and assign the addess to pointer
		tree1=(TTree*)InFile.Get("DataTree");
		
	}
	
	//  If loading the file or TTree failed the pointer tree1 is still empty
	if(tree1==nullptr){ 
		
		// Create an empty ttree to avoid segfault crash in this case
		tree1= new TTree();
		
	}

	//  Create a new histogram as local variable
	TH1D h1("H1","Charge",100,0,10000);

	// Draw the histogram to the screen (creates a TCanvas is needed)
	tree1->Draw("HPGeCharge>>H1");
	
}
