{
	
	
	//  A pointer for the TTree object, initially empty
	TTree* tree1=nullptr;
	TGraph* graph1=nullptr;
		
	//  Create a TFile object to access .root files
	TFile InFile("TTreeThree.root","READ");
	
	//  Check the .root file was found and opened.
	if(InFile.IsOpen()){
		
		//  Load the object saved with name "hist" into memory and assign the addess to pointer
		tree1=(TTree*)InFile.Get("DataTree");
		graph1=(TGraph*)InFile.Get("ThetaBeta");
	}
	
	//  If loading the file or histogram failed the pointer h1 is still empty
	if(tree1==nullptr){ 
		
		// Create an empty ttree to avoid segfault crash in this case
		tree1= new TTree();
		
	}
	
	if(graph1==nullptr){ 
		graph1= new TGraph();
	}
	
	
	TVector3 *ParticleVec,*GammaVec;
	double GammaEnergy,ParticleEnergy;
	
	tree1->SetBranchAddress("GammaVec", &GammaVec);
	tree1->SetBranchAddress("GammaEnergy", &GammaEnergy);
	tree1->SetBranchAddress("ParticleVec", &ParticleVec);
	tree1->SetBranchAddress("ParticleEnergy", &ParticleEnergy);
	
	//  Create a new histogram as local variable
	TH1D h1("H1","Energy",2000,0,2000);
	TH1D h2("H2","Energy",2000,0,2000);
	TH1D h3("H3","Energy",2000,0,2000);

	Int_t nentries = tree1->GetEntries();
	for(int jentry = 0; jentry<nentries; jentry++){
		tree1->GetEntry(jentry);
	
			
			double beta=graph1->Eval(ParticleVec->Theta());
			double dTheta=ParticleVec->Angle(*GammaVec);
			GammaEnergy*=(1-beta*cos(dTheta))/sqrt(1-beta*beta);
			h1.Fill(GammaEnergy);
			
		if(ParticleEnergy<80000){
			h2.Fill(GammaEnergy);
		}else{
			h3.Fill(GammaEnergy);
		}
	}
	
	h1.DrawCopy();
	h2.SetLineColor(EColor::kRed);
	h2.DrawCopy("same");
	h3.SetLineColor(EColor::kGreen);
	h3.DrawCopy("same");
	
}

