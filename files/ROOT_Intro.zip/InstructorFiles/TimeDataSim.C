void TimeDataSim(){

    TRandom R1;
	R1.SetSeed();
	
	double Twindow=400;
	double Toffset=15.6;
	double Tsigma=5.8;
	
	double Rate=10000; 
	
	double GammaEff=0.15;
	double ScintEff=0.45;
	
	vector<double> EY{R1.Uniform()*1500+100,R1.Uniform()*1500+100,R1.Uniform()*1500+100,R1.Uniform()*1500+100,511};
	vector<double> EI{0.2,1,R1.Uniform(),R1.Uniform(),1};
	vector<double> tau{28.56,2100.356,0,0,0};
	
	int Ny=EY.size();
	TH1D GammaPick("GammaPick","GammaPick",Ny,0,Ny);
	
	vector<TH1*> gammadist;
	
    for(unsigned int i=0;i<Ny;i++){
        stringstream ss;ss<<"hist"<<i;
        TH1* h=GenGeResponse(EY[i]);
        h->SetName(ss.str().c_str());
        gammadist.push_back(h);
		GammaPick.SetBinContent(i+1,EI[i]);
    }

    
	double T_MeV=5;
	TH1D beta_dist_hist("beta_dist_hist","beta_dist_hist",10000,0,T_MeV+0.001);
	for(int i=1;i<=beta_dist_hist.GetNbinsX();i++){
		double x=beta_dist_hist.GetXaxis()->GetBinCenter(i);
		beta_dist_hist.SetBinContent(i,unnorm_beta_dist_TKE(x,T_MeV,-30)*0.001);
	}
	beta_dist_hist.Scale(1/beta_dist_hist.Integral());
	beta_dist_hist.ComputeIntegral();

	double HPGeEnergy, ScintEnergy;
	int TimeStampHPGe,TimeStampScint;
    
	TFile* output_file = new TFile("TTreeTwo.root","RECREATE");
	output_file->cd();
        TTree* outtree = new TTree("DataTree","DataTree");
        outtree->Branch("HPGeEnergy", &HPGeEnergy);
        outtree->Branch("ScintEnergy", &ScintEnergy);
        outtree->Branch("TimeStampHPGe", &TimeStampHPGe,"TimeStampHPGe/I");
        outtree->Branch("TimeStampScint", &TimeStampScint,"TimeStampScint/I");
	gROOT->cd();
    

    std::vector< double > Eyv,Tyv,Esv,Tsv;
    
	long TimeStamp=0;
	
    int N=100000;
	
	for(int jentry = 0; jentry<N; jentry++){
		
		TimeStamp+=R1.Uniform(Rate);
   
		if(ScintEff>R1.Uniform()){
			Esv.push_back(beta_dist_hist.GetRandom());
			Tsv.push_back(TimeStamp);
		}else{
			Esv.push_back(-1);
			Tsv.push_back(-1000);
		}	
		
		
        unsigned int iy=GammaPick.GetRandom();
		if(GammaEff>R1.Uniform()){
			Eyv.push_back(gammadist[iy]->GetRandom());
			double yT=TimeStamp+Toffset;
			if(tau[iy]>0)yT+=R1.Exp(tau[iy]);
			Tyv.push_back(yT);
		}else{
			Eyv.push_back(-1);
			Tyv.push_back(-1000);
		}
		
		for(unsigned int i=0;i<Eyv.size();i++){
			for(unsigned int j=0;j<Esv.size();j++){
				if(Eyv[i]>0&&Esv[j]>0&&abs(Tyv[i]-Tsv[j])<Twindow){
					HPGeEnergy=Eyv[i];
					TimeStampHPGe=Tyv[i]+R1.Gaus(0,Tsigma);
					ScintEnergy=Esv[j];
					TimeStampScint=Tsv[j];
					outtree->Fill();
				}
			}
		}
		
		if(Eyv.size()>3){
			Eyv.erase(Eyv.begin());
			Tyv.erase(Tyv.begin());
			Esv.erase(Esv.begin());
			Tsv.erase(Tsv.begin());
		}
		
		
        if(jentry%100 == 0){
            cout << setiosflags(ios::fixed) << std::setprecision(2) << 100.*(double)jentry/N << " % complete."<<"\r" << flush; 
        }
	}
	
	output_file->Write();
    
    gSystem->Exit(0);
}

	

