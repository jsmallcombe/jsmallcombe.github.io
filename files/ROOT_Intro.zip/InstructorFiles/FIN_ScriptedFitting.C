{
	//  A pointer for the TTree object, initially empty
	TTree* tree1=nullptr;
		
	//  Create a TFile object to access .root files
	TFile InFile("TTreeOne.root","READ");
	
	//  Check the .root file was found and opened.
	if(InFile.IsOpen()){
		
		//  Load the object saved with name "hist" into memory and assign the addess to pointer
		tree1=(TTree*)InFile.Get("DataTree");
		
	}
	
	//  If loading the file or histogram failed the pointer h1 is still empty
	if(tree1==nullptr){ 
		
		// Create an empty ttree to avoid segfault crash in this case
		tree1= new TTree();
		
	}

	//  Create a new histogram as local variable
	TH1D h1("H1","Charge",2000,0,2E6);
	TH1D h2("H2","Energy",2000,0,2E3);
	TH1D h3("H3","EnergySum",2000,0,2E3);

	// Declare a TF1 (one dimentional function) object to hold the formula and parameters we will fit
	TF1 f1("f1","gaus(0)+pol1(3)",4E5,8E5);
	
	// Manually create a new TCanvas drawing environment each rather than having root automatically create one when draw is called 
	TCanvas C1("C1","C1",1200,500);
	
	// Divide the TCanvas drawing environment to draw histograms side-by-side
	C1.Divide(3);
	
	// loop over different ID values
	for(int id=0;id<3;id++){
		
		C1.cd(id+1);
		
		stringstream ss;
		ss<<"ShieldCharge<=0&&ID=="<<id;
		
		tree1->Draw("HPGeCharge>>H1",ss.str().c_str());
		
		double E1=h1.GetBinCenter(h1.GetMaximumBin());
		double gain=1173.238/E1;
		cout<<endl<<"Channel "<<id<<" approx gain."<<gain<<endl;
		
		double H1=h1.GetBinContent(h1.GetMaximumBin());
		
		
		h1.GetXaxis()->SetRangeUser(1200/gain,1500/gain);

		double E2=h1.GetBinCenter(h1.GetMaximumBin());
		double H2=h1.GetBinContent(h1.GetMaximumBin());
		
		h1.GetXaxis()->SetRange();
		
		f1.SetRange(E1-50/gain,E1+50/gain);
		f1.SetParameters(H1,E1,h1.GetBinWidth(1),h1.GetBinContent(h1.FindBin(E1-50/gain)),0);
		h1.Fit(&f1,"QR");
		
		gain=1173.238/f1.GetParameter(1);
		cout<<"Channel "<<id<<" less approx gain."<<gain<<endl;

		TGraph tmp;
		tmp.SetPoint(0,f1.GetParameter(1),1173.238);
		
		
		f1.SetRange(E2-50/gain,E2+50/gain);
		f1.SetParameters(H2,E2,h1.GetBinWidth(1),h1.GetBinContent(h1.FindBin(E2-50/gain)),0);
		h1.Fit(&f1,"QR+");
		
		tmp.SetPoint(1,f1.GetParameter(1),1332.502);
		
		TF1 p1("tmp","pol1");
		tmp.Fit(&p1,"Q");
		cout<<"Full Fit gain"<<p1.GetParameter(1)<<" offset"<<p1.GetParameter(0)<<endl;
		
		stringstream sss;
		sss<<"HPGeCharge*"<<p1.GetParameter(1)<<"+"<<p1.GetParameter(0)<<">>H2";
		
		tree1->Draw(sss.str().c_str(),ss.str().c_str());
		h3.Add(&h2);
		
		h1.DrawCopy();
		
		
	}
	new TCanvas();
	h3.DrawCopy();
}
