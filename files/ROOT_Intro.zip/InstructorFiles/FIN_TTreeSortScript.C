{
	
	
	//  A pointer for the TTree object, initially empty
	TTree* tree1=nullptr;
		
	//  Create a TFile object to access .root files
	TFile InFile("TTreeTwo.root","READ");
	
	//  Check the .root file was found and opened.
	if(InFile.IsOpen()){
		//  Load the object saved with name "hist" into memory and assign the addess to pointer
		tree1=(TTree*)InFile.Get("DataTree");
	}
	
	//  If loading the file or histogram failed the pointer h1 is still empty
	if(tree1==nullptr){ 
		// Create an empty ttree to avoid segfault crash in this case
		tree1= new TTree();
	}

	double HPGeEnergy, ScintEnergy;
	int TimeStampHPGe,TimeStampScint;
	
	tree1->SetBranchAddress("HPGeEnergy", &HPGeEnergy);
	tree1->SetBranchAddress("ScintEnergy", &ScintEnergy);
	tree1->SetBranchAddress("TimeStampHPGe", &TimeStampHPGe);
	tree1->SetBranchAddress("TimeStampScint", &TimeStampScint);

	//  Create a new histogram as local variable
	TH2F h1("H1","EnergyVsDeltaTime",2000,0,2000,1000,-500,500);

	Int_t nentries = tree1->GetEntries();
	for(int jentry = 0; jentry<nentries; jentry++){
		tree1->GetEntry(jentry);
		h1.Fill(HPGeEnergy,TimeStampHPGe-TimeStampScint);
	}
	
	new TCanvas();
	h1.DrawCopy("col");
	
	new TCanvas();
	TH1D *Five=h1.ProjectionY("five",h1.GetXaxis()->FindBin(506),h1.GetXaxis()->FindBin(516));
	TF1 g0("g0","gaus(0)+pol0(3)",-100,100);
	g0.SetParameters(1000,10,5,1);
	Five->Fit(&g0,"RL");
	
	new TCanvas();
	TH1D *Short=h1.ProjectionY("short",h1.GetXaxis()->FindBin(408),h1.GetXaxis()->FindBin(416));
	TF1 expo1("expo1","expo",g0.GetParameter(1)+g0.GetParameter(2)*4,390);
	expo1.SetParameters(100,-0.1);
	expo1.SetLineColor(EColor::kBlack);
	Short->Fit(&expo1,"RQ");
	double tau=-1/expo1.GetParameter(1);
	cout<<endl<<"Tau = "<<tau<<" +- "<<tau*expo1.GetParError(1)/expo1.GetParameter(1);
	expo1.SetLineColor(EColor::kRed);
	Short->Fit(&expo1,"RQL+");
	tau=-1/expo1.GetParameter(1);
	cout<<endl<<"Tau = "<<tau<<" +- "<<tau*expo1.GetParError(1)/expo1.GetParameter(1);
	
	
	TF1 expo2("expo2","expo(0)+pol0(2)",g0.GetParameter(1)+g0.GetParameter(2)*4,390);
	expo2.SetParameters(expo1.GetParameter(0),expo1.GetParameter(1),0);
	expo2.SetLineColor(EColor::kBlue);
	Short->Fit(&expo2,"RQ+");
	tau=-1/expo2.GetParameter(1);
	cout<<endl<<"Tau = "<<tau<<" +- "<<tau*expo2.GetParError(1)/expo2.GetParameter(1);
	expo2.SetLineColor(EColor::kGreen);
	Short->Fit(&expo2,"RQL+");
	tau=-1/expo2.GetParameter(1);
	cout<<endl<<"Tau = "<<tau<<" +- "<<tau*expo2.GetParError(1)/expo2.GetParameter(1);
	cout<<endl;
	
	new TCanvas();
	TH1D *Long=h1.ProjectionY("long",h1.GetXaxis()->FindBin(1250),h1.GetXaxis()->FindBin(1260));
	
	TF1 convo("convo","exp(([1]-x)/[3])*TMath::Erfc(([1]-x)/([2]*sqrt(2)) + [2]/([3]*sqrt(2)))*[0]+[4]",-390,390);
	convo.SetParameters(1,g0.GetParameter(1),g0.GetParameter(2),1000,0);
	convo.FixParameter(1,g0.GetParameter(1));
	convo.FixParameter(2,g0.GetParameter(2));
	Long->Fit(&convo,"RL");
	
	
	
}

